package com.jackyshan.itm.app.database;

import com.jackyshan.itm.app.database.dbmodel.DBBookModel;
import com.jackyshan.itm.app.database.dbworker.BookWorker;

import java.util.List;

/**
 * Created by jackyshan on 15/5/13.
 */
public class DataBaseServer {
    //书
    public static void insertBooks() {
        BookWorker.initInsertBooks();
    }
    public static List<DBBookModel> selectBooks() {
        return BookWorker.initSelectBooks();
    }
    public static void clearBooks() {
        BookWorker.initClearBooks();
    }
}
