package com.jackyshan.itm.app.database.dbmodel;

import com.activeandroid.annotation.Column;
import com.activeandroid.annotation.Table;
import com.jackyshan.itm.app.general.base.BaseModel;

/**
 * Created by jackyshan on 15/5/13.
 */
@Table(name = "DBBookModel")
public class DBBookModel extends BaseModel {

    @Column(name = "BookId")
    public int bookId;

    @Column(name = "BookName")
    public String bookName;

    @Column(name = "BookAuthor")
    public String bookAuthor;

    public  DBBookModel() {
        super();
    }
}
