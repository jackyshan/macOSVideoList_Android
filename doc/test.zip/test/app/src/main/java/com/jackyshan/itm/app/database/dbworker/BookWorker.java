package com.jackyshan.itm.app.database.dbworker;

import com.activeandroid.ActiveAndroid;
import com.activeandroid.query.Delete;
import com.activeandroid.query.Select;
import com.jackyshan.itm.app.database.dbmodel.DBBookModel;

import java.util.List;

/**
 * Created by jackyshan on 15/5/13.
 */
public class BookWorker {

    public static void initInsertBooks() {
        ActiveAndroid.beginTransaction();
        try {
            for (int i = 0; i < 3; i++) {
                DBBookModel book = new DBBookModel();
                book.bookId = i;
                book.bookName = "红楼梦" + i;
                book.bookAuthor = "曹雪芹" + i;
                book.save();
            }
            ActiveAndroid.setTransactionSuccessful();
        } finally {
            ActiveAndroid.endTransaction();
        }
    }

    public static List<DBBookModel> initSelectBooks() {
        return new Select()
                .from(DBBookModel.class)
                .execute();
    }

    public static void initClearBooks() {
        new Delete()
                .from(DBBookModel.class)
                .execute();
    }
}
