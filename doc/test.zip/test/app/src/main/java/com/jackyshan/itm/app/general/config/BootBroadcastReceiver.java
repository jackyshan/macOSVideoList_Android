package com.jackyshan.itm.app.general.config;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.jackyshan.itm.app.general.singleton.AppContext;
import com.jackyshan.itm.app.ui.login.WelcomeActivity;
import com.jackyshan.itm.app.utils.LogUtil;

/**
 * Created by jackyshan on 15/5/12.
 * 开机启动监听
 */
public class BootBroadcastReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent.getAction().equals("android.intent.action.BOOT_COMPLETED")) {//开机启动
            // doSomething(startService or startAcvitity or downLoadFile ...)
            LogUtil.LogMsg(AppContext.getInstance().getClass(), "--------------开机启动完成----------------");
            Intent lauch_intent = new Intent(context, WelcomeActivity.class);
            lauch_intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(lauch_intent);
        }
        else if (intent.getAction().equals("com.android.launcher.action.INSTALL_SHORTCUT")) {//添加图标
            LogUtil.LogMsg(AppContext.getInstance().getClass(),"-------------添加图标Receiver收到----------------");
            AppConfig.addShortcut();
        }
    }
}