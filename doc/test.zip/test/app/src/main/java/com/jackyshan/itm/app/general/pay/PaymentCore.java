package com.jackyshan.itm.app.general.pay;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import com.alipay.sdk.app.PayTask;
import com.jackyshan.itm.app.general.base.BaseObject;
import com.jackyshan.itm.app.general.config.AppConfig;
import com.jackyshan.itm.app.general.pay.wxapi.WXPayEntryActivity;
import com.jackyshan.itm.app.general.singleton.AppContext;
import com.tencent.mm.sdk.modelbase.BaseResp;
import com.tencent.mm.sdk.modelpay.PayReq;
import com.tencent.mm.sdk.openapi.IWXAPI;
import com.tencent.mm.sdk.openapi.WXAPIFactory;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by jackyshan on 15/5/15.
 */
public class PaymentCore extends BaseObject {
    /**
     * 支付通道类型
     */
    public enum PayType {
        PayTypeALiPay(0),   //支付宝
        PayTypeWeChat(1);   //微信

        public int type;

        private PayType(int type) {
            this.type = type;
        }
    }

    /**
     * 支付业务类型
     */
    public enum BusiType {
        BusiTypeCourse(0);  //购买课程

        public int type;

        private BusiType(int type) {
            this.type = type;
        }
    }

    //变量
    private OnResultListener listener;
    private Map params;

    //回调
    public interface OnResultListener {
        void onResult(Boolean succ, Object result);
    }

    /**
     * 购买商品
     *
     * @param params   参数
     * @param listener 回调
     */
    public void buyGoods(Map params, OnResultListener listener) {
        this.listener = listener;
        this.params = params;

        getOrderId(params);
    }

    //订单id
    private void getOrderId(Map params) {
        getOrderInfo(null);
    }

    //订单info
    private void getOrderInfo(Map params) {
        payAction(null);
    }

    //支付方式
    private void payAction(final Map params) {
        int type = (Integer) this.params.get("payType");

        if (type == PayType.PayTypeALiPay.type) {
            final String orderInfo = "partner=\"2088901979391941\"&seller_id=\"1098813443@qq.com\"&out_trade_no=\"0515025240-4737\"&subject=\"测试商品\"&body=\"测试商品的详细描述\"&total_fee=\"0.01\"&notify_url=\"http://notify.msp.hk/notify.htm\"&service=\"mobile.securitypay.pay\"&payment_type=\"1\"&_input_charset=\"utf-8\"&it_b_pay=\"30m\"&show_url=\"m.alipay.com\"&sign=\"lPDAE%2Bbkdah%2BcaGB0M4JxssCkurx1kFpHbHZKZ6tDJjWEa7WPuQa9w0U%2F%2FtJkNDqhWpZd9aew%2FlyLZEclUzOaDjOkTgupxpOr9exzSkhSIpPjPGBmMk5eZnNKFpqH5ppYznkjAGJ9oiLv%2B%2BBuvzHK%2FzEoYrSu0DWzreVYwEpCNg%3D\"&sign_type=\"RSA\"";

            new Thread() {
                @Override
                public void run() {
                    PayTask alipay = new PayTask(AppContext.getInstance().getTheTopActivity());
                    String resultInfo = alipay.pay(orderInfo);
                    Result result = new Result(resultInfo);
                    logMsg(result.toString());
                    if (result.resultStatus.equals("9000")) {
                        checkOrderStatus(null);
                    } else {
                        listener.onResult(false, result.memo);
                    }
                }
            }.start();
        } else if (type == PayType.PayTypeWeChat.type) {
            new Thread() {
                @Override
                public void run() {
                    IWXAPI wxApi = WXAPIFactory.createWXAPI(AppContext.getInstance().getTheTopActivity(), AppConfig.APP_ID);
                    wxApi.registerApp(AppConfig.APP_ID);
                    handleWxPay(AppContext.getInstance().getTheTopActivity());
                    if (wxApi.isWXAppInstalled()) {
                        PayReq req = new PayReq();
                        req.appId = AppConfig.APP_ID;
                        req.partnerId = "1226432401";
                        req.prepayId = "1201000000150517e7c4aede37124da1";
                        req.nonceStr = "acf4b89d3d503d8252c9c4ba75ddbf6d";
                        req.timeStamp = "1431870325";
                        req.packageValue = "Sign=WXPay";
                        req.sign = "8878f0e515dfb251ac8aeba59ca773dbadfa20f1";
                        req.extData = "app data"; // optional

                        if (!wxApi.sendReq(req)) {
                            listener.onResult(false, "微信请求失败");
                        }
                    } else {
                        listener.onResult(false, "未安装微信");
                    }
                }
            }.start();
        } else {
            logMsg("未知支付方式");
        }
    }

    //查询订单
    private void checkOrderStatus(Map params) {
        listener.onResult(true, null);
    }

    //处理微信结果
    private void handleWxPay(Context context) {
        BroadcastReceiver wxPayResultReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (WXPayEntryActivity.ACTION_PAY_RESULT.equals(intent.getAction())) {
                    Bundle bundle = intent.getExtras();
                    BaseResp resp = new BaseResp() {
                        @Override
                        public int getType() {
                            return 0;
                        }

                        @Override
                        public boolean checkArgs() {
                            return false;
                        }
                    };
                    resp.fromBundle(bundle);
                    String errMsg = "";
                    if (resp.errCode == BaseResp.ErrCode.ERR_OK) {
                        errMsg = "微信客户端验证支付成功";
                        checkOrderStatus(null);
                    } else {
                        errMsg = resp.errStr;
                    }
                    logMsg(errMsg);
                }
            }
        };

        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(WXPayEntryActivity.ACTION_PAY_RESULT);
        context.registerReceiver(wxPayResultReceiver, intentFilter);
    }
}
