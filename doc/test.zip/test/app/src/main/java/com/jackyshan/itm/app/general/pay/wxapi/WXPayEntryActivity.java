package com.jackyshan.itm.app.general.pay.wxapi;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import com.jackyshan.itm.app.general.config.AppConfig;
import com.jackyshan.itm.app.utils.LogUtil;
import com.tencent.mm.sdk.constants.ConstantsAPI;
import com.tencent.mm.sdk.modelbase.BaseReq;
import com.tencent.mm.sdk.modelbase.BaseResp;
import com.tencent.mm.sdk.openapi.IWXAPI;
import com.tencent.mm.sdk.openapi.IWXAPIEventHandler;
import com.tencent.mm.sdk.openapi.WXAPIFactory;

/**
 * Created by jackyshan on 15/5/15.
 */
public class WXPayEntryActivity extends Activity implements IWXAPIEventHandler {
    public final static String ACTION_PAY_RESULT = AppConfig.AppName+"weixin_pay_result";

    // IWXAPI 是第三方app和微信通信的openapi接口
    private IWXAPI api;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        api = WXAPIFactory.createWXAPI(this, AppConfig.APP_ID, false);
        api.handleIntent(getIntent(), this);
    }
    @Override
    public void onReq(BaseReq req) {
        LogUtil.LogMsg(WXPayEntryActivity.class, "微信支付请求req=" + req);
    }

    @Override
    public void onResp(BaseResp resp) {
        LogUtil.LogMsg(WXPayEntryActivity.class, "微信返回结果errCode=" + resp.errCode + ", errStr=" + resp.errStr);
        // 微信支付
        if (resp.getType() == ConstantsAPI.COMMAND_PAY_BY_WX) {
            Intent intent = new Intent();
            Bundle bundle = new Bundle();
            resp.toBundle(bundle);
            intent.putExtras(bundle);
            intent.setAction(ACTION_PAY_RESULT);
            sendBroadcast(intent);
        }
        finish();
    }
}
