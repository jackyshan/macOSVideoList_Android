package com.jackyshan.itm.app.models;

import com.jackyshan.itm.app.general.base.BaseModel;
import com.jackyshan.itm.app.utils.JsonHelper;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by jackyshan on 15/5/10.
 */

public class FragmentModel extends BaseModel {
    public String name;
    public int age;
    public static List<FragmentModel> arrayfromJsonList(String json) {
        List<FragmentModel> mArr = new ArrayList<FragmentModel>();
        List<Map> mapList = (List<Map>) JsonHelper.json2List(json);

        for (Map map : mapList) {
            FragmentModel model = new FragmentModel();
            model.setModelByMap(map);
            mArr.add(model);
        }
        return mArr;
    }
}