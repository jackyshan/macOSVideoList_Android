package com.jackyshan.itm.app.network;

import android.content.Context;
import com.jackyshan.itm.app.general.base.BaseNetwork;
import com.jackyshan.itm.app.models.FragmentModel;

import java.util.List;
import java.util.Map;

/**
 * Created by jackyshan on 15/5/10.
 */
public class NWFragmentList extends BaseNetwork {

    @Override
    public void startRequest(Map map) {
        super.startRequest(map);

        path = "adat/sk/101010100.html";
        params = map;
        startGet();
    }

    @Override
    protected void dealComplete(Boolean succ, String json) {
        super.dealComplete(succ, json);

        if (succ) {
            List<FragmentModel> list = FragmentModel.arrayfromJsonList(json);

            listener.onResult(true, list);
        }
    }
}
