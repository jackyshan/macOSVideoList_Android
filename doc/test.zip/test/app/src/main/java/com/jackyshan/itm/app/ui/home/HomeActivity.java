package com.jackyshan.itm.app.ui.home;

import android.os.Bundle;
import com.jackyshan.itm.app.R;
import com.jackyshan.itm.app.general.base.BaseActivity;

public class HomeActivity extends BaseActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        initViews();
        setViews();
    }

    @Override
    protected void initViews() {
        super.initViews();
    }

    @Override
    protected void setViews() {
        super.setViews();
        setTitle("Home");
        navigationBar.setLeftGone();
    }
}
