package com.jackyshan.itm.app.ui.login;

import android.content.Intent;
import android.os.Bundle;
import com.jackyshan.itm.app.R;
import com.jackyshan.itm.app.general.base.BaseActivity;
import com.jackyshan.itm.app.ui.home.HomeActivity;
import com.jackyshan.itm.app.ui.tab.MainTabActivity;

public class WelcomeActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        Intent intent = new Intent(WelcomeActivity.this, MainTabActivity.class);
        startActivity(intent);
        finish();
    }
}