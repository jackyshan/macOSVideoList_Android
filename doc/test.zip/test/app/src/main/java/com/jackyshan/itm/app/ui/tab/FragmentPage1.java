package com.jackyshan.itm.app.ui.tab;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import com.jackyshan.itm.app.R;
import com.jackyshan.itm.app.general.base.BaseFragment;
import com.jackyshan.itm.app.general.base.BaseNetwork;
import com.jackyshan.itm.app.network.NWFragmentList;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FragmentPage1 extends BaseFragment {
    View view;
    ListView lv_listview;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        if (view == null) {
            initView(inflater);
            setView();
        }

        //缓存的rootView需要判断是否已经被加过parent， 如果有parent需要从parent删除，要不然会发生这个rootview已经有parent的错误。
        ViewGroup parent = (ViewGroup) view.getParent();
        if (parent != null) {
            parent.removeView(view);
        }

        return view;
    }

    protected void initView(LayoutInflater inflater) {
        view = inflater.inflate(R.layout.fragment_1, null);
        lv_listview = (ListView) view.findViewById(R.id.lv_listview);
    }

    protected void setView() {
        String[] from = new String[] {"item_title"};
        int[] to = new int[] {R.id.item_title};

        // 创建动态数组数据源
        List<HashMap<String, Object>> data = new ArrayList<HashMap<String, Object>>();
        for (int i = 0; i < 20; i++) {
            HashMap<String, Object> map = new HashMap<String, Object>();
            map.put("item_title", ""+i);
            data.add(map);
        }

        lv_listview.setAdapter(new SimpleAdapter(mActivity, data, R.layout.list_item, from, to));

        lv_listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                getData();
            }
        });
    }

    @Override
    protected void getData() {
        super.getData();

        NWFragmentList fragmentList = new NWFragmentList();
        fragmentList.setOnResultListener(new BaseNetwork.OnResultListener() {
            @Override
            public void onResult(Boolean succ, List<?> list) {
                //logMsg("请求网络成功，返回成功"+succ+list);
            }
        });
        Map<String, String> params = new HashMap<String, String>();
        params.put("format", "json");
        fragmentList.startRequest(params);
    }
}
