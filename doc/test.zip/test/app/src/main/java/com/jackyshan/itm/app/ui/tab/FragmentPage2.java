package com.jackyshan.itm.app.ui.tab;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import com.jackyshan.itm.app.R;
import com.jackyshan.itm.app.general.base.BaseFragment;
import com.jackyshan.itm.app.general.help.CommonHelp;

public class FragmentPage2 extends BaseFragment {
	View view;
	ImageView imgv;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) {
		super.onCreateView(inflater, container, savedInstanceState);
		if (view == null) {
			initView(inflater);
			setView();
		}

		//缓存的rootView需要判断是否已经被加过parent， 如果有parent需要从parent删除，要不然会发生这个rootview已经有parent的错误。
		ViewGroup parent = (ViewGroup) view.getParent();
		if (parent != null) {
			parent.removeView(view);
		}

		return view;
	}

	protected void initView(LayoutInflater inflater) {
		view =  inflater.inflate(R.layout.fragment_2, null);
		imgv = (ImageView) view.findViewById(R.id.imgV);
	}

	protected void setView() {
		CommonHelp.loadImgV(imgv, "http://ips.chotee.com/wp-content/uploads/2013/flickr/design.jpg", R.drawable.ic_launcher);
	}
}