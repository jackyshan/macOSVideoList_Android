package com.jackyshan.itm.app.ui.tab;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import com.jackyshan.itm.app.R;
import com.jackyshan.itm.app.database.DataBaseServer;
import com.jackyshan.itm.app.database.dbmodel.DBBookModel;
import com.jackyshan.itm.app.general.base.BaseFragment;

import java.util.List;

public class FragmentPage3 extends BaseFragment {
    View view;

    MyAdapter adapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        if (view == null) {
            initView(inflater);
        }

        //缓存的rootView需要判断是否已经被加过parent， 如果有parent需要从parent删除，要不然会发生这个rootview已经有parent的错误。
        ViewGroup parent = (ViewGroup) view.getParent();
        if (parent != null) {
            parent.removeView(view);
        }

        return view;
    }

    protected void initView(LayoutInflater inflater) {
        view = inflater.inflate(R.layout.fragment_3, null);

        Button insertBook = (Button) view.findViewById(R.id.btn_insert);
        Button clearBook = (Button) view.findViewById(R.id.btn_clear);

        insertBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DataBaseServer.insertBooks();
                adapter.notifyDataSetChanged();
            }
        });

        clearBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DataBaseServer.clearBooks();
                adapter.notifyDataSetChanged();
            }
        });

        ListView listView = (ListView) view.findViewById(R.id.lv_listview);
        adapter = new MyAdapter(mActivity);
        listView.setAdapter(adapter);
    }

    // ViewHolder静态类
    static class ViewHolder {
        public TextView number;
        public TextView bookName;
        public TextView bookAuthor;
    }

    private class MyAdapter extends BaseAdapter {

        private LayoutInflater mInflater = null;
        private List<DBBookModel> list;

        private MyAdapter(Context context) {
            // 根据context上下文加载布局
            this.mInflater = LayoutInflater.from(context);
        }

        @Override
        public int getCount() {
            list = DataBaseServer.selectBooks();
            return list.size();
        }

        @Override
        public Object getItem(int i) {
            return list.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int i, View container, ViewGroup viewGroup) {
            ViewHolder holder = null;
            if (container == null) {
                holder = new ViewHolder();

                container = mInflater.inflate(R.layout.list_item_frag3, null);
                holder.number = (TextView) container.findViewById(R.id.tv_number);
                holder.bookName = (TextView) container.findViewById(R.id.tv_bookname);
                holder.bookAuthor = (TextView) container.findViewById(R.id.tv_author);

                // 将设置好的布局保存到缓存中，并将其设置在Tag里，以便后面方便取出Tag
                container.setTag(holder);
            }
            else {
                holder = (ViewHolder) container.getTag();
            }

            DBBookModel model = list.get(i);
            holder.number.setText("编号"+model.bookId);
            holder.bookName.setText("书名"+model.bookName);
            holder.bookAuthor.setText("作者"+model.bookAuthor);

            return container;
        }
    }
}