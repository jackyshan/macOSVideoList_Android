package com.jackyshan.itm.app.ui.tab;

import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import com.jackyshan.itm.app.R;
import com.jackyshan.itm.app.general.base.BaseFragment;
import com.jackyshan.itm.app.general.pay.PaymentCore;
import com.jackyshan.itm.app.general.singleton.SingletonInner;

import java.util.HashMap;

public class FragmentPage4 extends BaseFragment {
    View view;
    private Handler handler;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        if (view == null) {
            initView(inflater);
        }

        //缓存的rootView需要判断是否已经被加过parent， 如果有parent需要从parent删除，要不然会发生这个rootview已经有parent的错误。
        ViewGroup parent = (ViewGroup) view.getParent();
        if (parent != null) {
            parent.removeView(view);
        }

        return view;
    }

    @Override
    protected void initView(LayoutInflater inflater) {
        super.initView(inflater);

        view = inflater.inflate(R.layout.fragment_4, null);
        handler = new Handler();

        Button btnAli = (Button) view.findViewById(R.id.btn_alipay);
        btnAli.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toPay(PaymentCore.PayType.PayTypeALiPay.type);
            }
        });

        Button btnWechat = (Button) view.findViewById(R.id.btn_wechatpay);
        btnWechat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toPay(PaymentCore.PayType.PayTypeWeChat.type);
            }
        });
    }

    private void toPay(int type) {
        HashMap<String, Object> params = new HashMap<String, Object>();
        params.put("payType", type);

        SingletonInner.getInstance().paymentCore.buyGoods(params, new PaymentCore.OnResultListener() {
            @Override
            public void onResult(Boolean succ, Object result) {
                final String message;
                if (succ) {
                    message = "支付成功";
                }
                else {
                    message = result.toString();
                }

                handler.post(new Runnable() {// This thread runs in the UI
                    @Override
                    public void run() {// Update the UI
                        showToast(message);
                    }
                });
            }
        });
    }
}